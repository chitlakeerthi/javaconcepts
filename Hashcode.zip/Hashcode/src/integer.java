public class integer {  
    public static void main(String[] args)  
    {  
        Integer i = new Integer("111");     
        int hashValue = i.hashCode();  
        System.out.println("Hash code Value for object is: " + hashValue);  
    }  
}  